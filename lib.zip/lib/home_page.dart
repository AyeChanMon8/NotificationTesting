import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import 'incoming_call_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      String? title = "Aung Khant Kyaw";
      String? body = "Is Calling";
      AwesomeNotifications().createNotification(
          content: NotificationContent(
              id: 123,
              channelKey: 'call_channel',
              color: Colors.white,
              title: title,
              body: body,
              category: NotificationCategory.Call),
          actionButtons: [
            NotificationActionButton(
                key: "ACCEPT",
                label: "Accept Call",
                color: Colors.green,
                autoDismissible: true),
            NotificationActionButton(
                key: "REJECT",
                label: "Reject Call",
                color: Colors.red,
                autoDismissible: true)
          ]);
    });
  }

  @override
  Widget build(BuildContext context) {
    AwesomeNotifications().actionStream.listen((event) {
      if (event.buttonKeyPressed == "REJECT") {
        print("Call Rejected");
      } else if (event.buttonKeyPressed == 'ACCEPT') {
        print("Call Accepted");
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => IncomingCallPage()),
        );
      } else {
        print("Clicked on notifications");
      }
    });
    return Scaffold(
      body: Center(
        child: Text("Hi Test"),
      ),
    );
  }
}
